from django.db import models

# Create your models here. 

class Planet(models.Model):
    name = models.CharField(max_length=200) # Campo de caracteres com limite de 200
    diameter = models.PositiveIntegerField() # Campo numerico inteiro positivo
    rotation_period = models.CharField(max_length=200)
    orbital_period = models.CharField(max_length=200)
    gravity = models.CharField(max_length=300)
    climate = models.CharField(max_length=200)
    terrain = models.CharField(max_length=200)
    created = models.DateField(editable=False, auto_now=True) # campo de data neste modelo: yyyy-mm-dd, que não é editavel e gera a data na hora da criação 