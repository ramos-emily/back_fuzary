from django.contrib import admin
from .models import *
# Register your models here.


class datPlanet(admin.ModelAdmin):
    list_display = ('id', 'name', 'climate')
    list_display_links = ('id', 'name',)
    search_fields = ('name',)
    list_per_page = 10 

admin.site.register(Planet, datPlanet)
